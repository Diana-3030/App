<?php
header('Access-Control-Allow-Origin: *'); 
defined('BASEPATH') OR exit('No direct script access allowed');

class Maquinarias extends MY_Controller {
        
    public function __construct() {
        parent::__construct();
    }

    public function GetMaquinarias() {
        $respuesta = $this->Query_Model->GetMaquinarias();
        echo json_encode($respuesta);
    }

    public function getMaquinaria() {
        $id = $this->input->get('id');
        $respuesta = $this->Query_Model->GetMaquinariaById($id);
        echo json_encode($respuesta);
    }

    public function saveMaquinaria() {
        $nombre = $this->input->post('nombre');
        $descripcion = $this->input->post('descripcion');
        $area = $this->input->post('area');
        $data = array(
            'nombre' => $nombre,
            'descripcion' => $descripcion,
            'id_area' => $area
        );
        $this->Query_Model->InsertMaquinaria($data);
    }

    public function updateMaquinaria() {
        $id = $this->input->post('id');
        $nombre = $this->input->post('nombre');
        $descripcion = $this->input->post('descripcion');
        $area = $this->input->post('area');
        $data = array(
            'nombre' => $nombre,
            'descripcion' => $descripcion,
            'id_area' => $area
        );
        $this->Query_Model->UpdateMaquinaria($id, $data);
    }

    public function dropMaquinaria() {
        $id = $this->input->get('id');
        $this->Query_Model->DeleteMaquinaria($id);
    }

}
