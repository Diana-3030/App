<?php
header('Access-Control-Allow-Origin: *'); 
defined('BASEPATH') OR exit('No direct script access allowed');

class Sucursales extends MY_Controller {
        
    public function __construct() {
        parent::__construct();
    }

    public function getSucursales() {
        $respuesta = $this->Query_Model->GetSucursales();
        echo json_encode($respuesta);
    }

    public function getSucursal() {
        $id = $this->input->get('id');
        $respuesta = $this->Query_Model->GetSucursalById($id);
        echo json_encode($respuesta);
    }

    public function saveSucursal() {
        $direccion = $this->input->post('direccion');
        $numEmpl = $this->input->post('num_empleados');
        $data = array(
            'direccion' => $direccion,
            'num_empleados' => $numEmpl
        );
        $this->Query_Model->InsertSucursal($data);
    }

    public function updateSucursal() {
        $id = $this->input->post('id');
        $direccion = $this->input->post('direccion');
        $numEmpl = $this->input->post('num_empleados');
        $data = array(
            'direccion' => $direccion,
            'num_empleados' => $numEmpl
        );
        $this->Query_Model->UpdateSucursal($id, $data);
    }

    public function dropSucursal() {
        $id = $this->input->get('id');
        $this->Query_Model->DeleteSucursal($id);
    }

}
