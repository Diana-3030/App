<?php
header('Access-Control-Allow-Origin: *'); 
defined('BASEPATH') OR exit('No direct script access allowed');

class Session extends CI_Controller {
    
    private $redirectURL;
    
    public function __construct() {
        parent::__construct();
        $this->loaddependencies();
    }
    
    public function index(){

    }
    
    public function logout(){
        $user = $this->input->post('usuario');
        $this->Session_Model->CloseSession($user);
        $this->session->sess_destroy();
    }
  
    public function validatelogin(){

        $user = $this->input->post('usuario');
        $pass = $this->input->post('pass');
        $msg = "";

        $userSinSesion = $this->Session_Model->CheckSession($user);
        $valores = count($userSinSesion);
        if ($valores == 0) {
            $userExist = $this->Session_Model->checkinourdb($user);
            if($userExist->valido){
                $userValid = $this->Session_Model->checkinactivedirectory($user,$pass);
                if($userValid->valido){
                    $this->setsession('user', $userValid->user);
                    $this->setsession('name', $userValid->name);
                    $this->setsession('rol', $userValid->rol_user);

                    $user = $userValid->user;
                    $rol_user = $userValid->rol_user;
                    $this->Session_Model->TablaSesiones($user,$rol_user);
                    $msg = "OK-";
                    echo json_encode($msg);
                }else{
                    $msg = 'IUOP';
                    echo json_encode($msg); //Error: Incorrect User Or Password
                }
            }else{
                $msg = 'UWOA';
                echo json_encode($msg); //Error: User Without Access  
            }
        }else{
        $msg = "UWAS";
        echo json_encode($msg); //Error: User With Active Session
        }
    }

    public function setsession($type,$value){
        $newdata = array( 
            $type => $value 
        );
        $this->session->set_userdata($newdata);
    }
    
    public function loaddependencies(){
        $this->load->model('Session_Model');
    }

    public function Permisos(){

        $res = $this->session->userdata('rol');
        echo json_encode($res);
    }

    public function ResetLogin(){
        $user = $this->input->post("usuarioreset");
        $pass = $this->input->post("passreset");

        $UserExist = $this->Session_Model->checkinourdb($user);
        if ($UserExist->valido) {
            $userValid = $this->Session_Model->checkinactivedirectory($user,$pass);
            if($userValid->valido){

                $this->Session_Model->ResetSesion($user);
                echo json_encode("OK-");
            }else{
                echo json_encode("IUOP");
            }
        
        }else{
            echo json_encode("UWOA");
        }
    }
                                                     
                                                            
}