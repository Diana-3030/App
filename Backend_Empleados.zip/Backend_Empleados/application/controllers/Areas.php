<?php
header('Access-Control-Allow-Origin: *'); 
defined('BASEPATH') OR exit('No direct script access allowed');

class Areas extends MY_Controller {
        
    public function __construct() {
        parent::__construct();
    }

    public function GetAreas() {
        $respuesta = $this->Query_Model->GetAreas();
        echo json_encode($respuesta);
    }

    public function getArea() {
        $id = $this->input->get('id');
        $respuesta = $this->Query_Model->GetAreaById($id);
        echo json_encode($respuesta);
    }

    public function saveArea() {
        $nombre = $this->input->post('nombre');
        $data = array(
            'nombre' => $nombre
        );
        $this->Query_Model->InsertArea($data);
    }

    public function updateArea() {
        $id = $this->input->post('id');
        $nombre = $this->input->post('nombre');
        $data = array(
            'nombre' => $nombre
        );
        $this->Query_Model->UpdateArea($id, $data);
    }

    public function dropArea() {
        $id = $this->input->get('id');
        $this->Query_Model->DeleteArea($id);
    }

}
