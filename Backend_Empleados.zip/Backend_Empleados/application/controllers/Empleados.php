<?php
header('Access-Control-Allow-Origin: *'); 
defined('BASEPATH') OR exit('No direct script access allowed');

class Empleados extends MY_Controller {
        
    public function __construct() {
        parent::__construct();
    }

    public function GetEmpleados() {
        $respuesta = $this->Query_Model->GetEmpleados();
        echo json_encode($respuesta);
    }

    public function getEmpleado() {
        $id = $this->input->get('id');
        $respuesta = $this->Query_Model->GetEmpleadoById($id);
        echo json_encode($respuesta);
    }

    public function saveEmpleado() {
        $nombre = $this->input->post('nombre');
        $apaterno = $this->input->post('apaterno');
        $amaterno = $this->input->post('amaterno');
        $area = $this->input->post('area');
        $data = array(
            'nombre' => $nombre,
            'apaterno' => $apaterno,
            'amaterno' => $amaterno,
            'id_area' => $area
        );
        $this->Query_Model->InsertEmpleado($data);
    }

    public function updateEmpleado() {
        $id = $this->input->post('id');
        $nombre = $this->input->post('nombre');
        $apaterno = $this->input->post('apaterno');
        $amaterno = $this->input->post('amaterno');
        $area = $this->input->post('area');
        $data = array(
            'nombre' => $nombre,
            'apaterno' => $apaterno,
            'amaterno' => $amaterno,
            'id_area' => $area
        );
        $this->Query_Model->UpdateEmpleado($id, $data);
    }

    public function dropEmpleado() {
        $id = $this->input->get('id');
        $this->Query_Model->DeleteEmpleado($id);
    }

}
