<?php

class Query_Model extends CI_Model{

    /* START - CONTROLLER: Areas */

    function GetAreas() {
        $this->db->select('*');
        $this->db->from('areas');
        $query = $this->db->get();
        return $query->result();
    }

    function InsertArea($datos) {
        $this->db->insert('areas', $datos);
    }

    function GetAreaById($id) {
        $this->db->select('*');
        $this->db->from('areas');
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->row();
    }

    function UpdateArea($id, $data) {
        $this->db->where('id', $id);
        $this->db->set($data);
        $this->db->update('areas');
    }

    function DeleteArea($id){
        $array = ['id' => $id];
        $this->db->delete('areas', $array);
    }

    /* START - CONTROLLER: Areas */

    /* START - CONTROLLER: Empleados */

    function GetEmpleados() {
        $this->db->select('*');
        $this->db->from('empleados');
        $query = $this->db->get();
        return $query->result();
    }

    function InsertEmpleado($datos) {
        $this->db->insert('empleados', $datos);
    }

    function GetEmpleadoById($id) {
        $this->db->select('*');
        $this->db->from('empleados');
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->row();
    }

    function UpdateEmpleado($id, $data) {
        $this->db->where('id', $id);
        $this->db->set($data);
        $this->db->update('empleados');
    }

    function DeleteEmpleado($id){
        $array = ['id' => $id];
        $this->db->delete('empleados', $array);
    }

    /* START - CONTROLLER: Empleados */

    /* START - CONTROLLER: Maquinaria */

    function GetMaquinarias() {
        $this->db->select('*');
        $this->db->from('maquinaria');
        $query = $this->db->get();
        return $query->result();
    }

    function InsertMaquinaria($datos) {
        $this->db->insert('maquinaria', $datos);
    }

    function GetMaquinariaById($id) {
        $this->db->select('*');
        $this->db->from('maquinaria');
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->row();
    }

    function UpdateMaquinaria($id, $data) {
        $this->db->where('id', $id);
        $this->db->set($data);
        $this->db->update('maquinaria');
    }

    function DeleteMaquinaria($id){
        $array = ['id' => $id];
        $this->db->delete('maquinaria', $array);
    }

    /* START - CONTROLLER: Maquinaria */

    /* START - CONTROLLER: Sucursal */

    function GetSucursales() {
        $this->db->select('*');
        $this->db->from('sucursales');
        $query = $this->db->get();
        return $query->result();
    }

    function InsertSucursal($datos) {
        $this->db->insert('sucursales', $datos);
    }

    function GetSucursalById($id) {
        $this->db->select('*');
        $this->db->from('sucursales');
        $this->db->where('id', $id);
        $query = $this->db->get();
        return $query->row();
    }

    function UpdateSucursal($id, $data) {
        $this->db->where('id', $id);
        $this->db->set($data);
        $this->db->update('sucursales');
    }

    function DeleteSucursal($id){
        $array = ['id' => $id];
        $this->db->delete('sucursales', $array);
    }

    /* START - CONTROLLER: Sucursal */
}